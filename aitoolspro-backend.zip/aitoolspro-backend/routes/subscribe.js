const express = require("express");
const router = express.Router();
const Subscriber = require("../models/Subscriber");
const requireAdmin = require("../middleware/requireAdmin");

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// POST /api/subscribe -> add a newsletter subscriber (public, used by the footer/hero form)
router.post("/", async (req, res) => {
  try {
    const { email } = req.body;
    if (!email || !emailRegex.test(email)) {
      return res.status(400).json({ error: "Please provide a valid email address." });
    }

    const existing = await Subscriber.findOne({ email: email.toLowerCase() });
    if (existing) {
      return res.status(200).json({ message: "You're already subscribed!" });
    }

    await Subscriber.create({ email });
    res.status(201).json({ message: "Subscribed successfully!" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/subscribe -> list all subscribers (admin only, e.g. to export for email campaigns)
router.get("/", requireAdmin, async (req, res) => {
  try {
    const subs = await Subscriber.find().sort({ createdAt: -1 });
    res.json({ count: subs.length, subscribers: subs });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
