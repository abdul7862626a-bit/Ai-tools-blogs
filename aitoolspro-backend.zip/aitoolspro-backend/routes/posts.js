const express = require("express");
const router = express.Router();
const { Post, makeSlug } = require("../models/Post");
const requireAdmin = require("../middleware/requireAdmin");

// GET /api/posts  -> list all posts (newest first)
router.get("/", async (req, res) => {
  try {
    const { category, limit } = req.query;
    const filter = category && category !== "all" ? { category } : {};
    const posts = await Post.find(filter)
      .sort({ createdAt: -1 })
      .limit(limit ? parseInt(limit, 10) : 0);
    res.json(posts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/posts/:slug -> single post + increments view count
router.get("/:slug", async (req, res) => {
  try {
    const post = await Post.findOneAndUpdate(
      { slug: req.params.slug },
      { $inc: { views: 1 } },
      { new: true }
    );
    if (!post) return res.status(404).json({ error: "Post not found" });
    res.json(post);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/posts -> create new post (from "Write New Blog Post" form). Requires admin key.
router.post("/", requireAdmin, async (req, res) => {
  try {
    const { title, category, subtitle, body, author, rating } = req.body;

    if (!title || !category || !body || !author) {
      return res.status(400).json({
        error: "title, category, body and author are required fields.",
      });
    }

    const words = body.trim().split(/\s+/).length;
    const readTime = Math.max(1, Math.round(words / 200)) + " min read";

    let slug = makeSlug(title);
    const existing = await Post.findOne({ slug });
    if (existing) slug = `${slug}-${Date.now()}`;

    const post = await Post.create({
      title,
      slug,
      category,
      subtitle,
      body,
      author,
      rating: rating || 5.0,
      readTime,
    });

    res.status(201).json(post);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/posts/:slug -> remove a post. Requires admin key.
router.delete("/:slug", requireAdmin, async (req, res) => {
  try {
    const deleted = await Post.findOneAndDelete({ slug: req.params.slug });
    if (!deleted) return res.status(404).json({ error: "Post not found" });
    res.json({ message: "Post deleted", slug: req.params.slug });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
