/* ============================================================
   AIToolsPro — Backend Connector
   Add this script before </body> in your index.html
   (after updating API_BASE_URL with your deployed Railway URL)
   ============================================================ */

const API_BASE_URL = "https://YOUR-RAILWAY-APP.up.railway.app"; // <-- change after deploy
const ADMIN_KEY = "change-this-to-a-strong-secret"; // <-- must match backend .env ADMIN_KEY

// ---------- 1. Load posts from backend and render them on the homepage ----------
async function loadPosts() {
  try {
    const res = await fetch(`${API_BASE_URL}/api/posts`);
    const posts = await res.json();
    renderPosts(posts);
  } catch (err) {
    console.error("Failed to load posts:", err);
  }
}

function renderPosts(posts) {
  const container = document.querySelector("#latest-articles-grid"); // <-- update selector to match your real HTML
  if (!container) return;
  container.innerHTML = posts
    .map(
      (p) => `
      <a href="post.html?slug=${p.slug}" class="article-card">
        <span class="badge">${p.category}</span>
        <h3>${p.title}</h3>
        <p>${p.subtitle || ""}</p>
        <span>★${p.rating} · ${p.readTime}</span>
      </a>`
    )
    .join("");
}

// ---------- 2. Handle "Write New Blog Post" form submission ----------
function setupPublishForm() {
  const form = document.querySelector("#publish-post-form"); // <-- update selector to match your real form id
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const payload = {
      title: form.querySelector("#post-title")?.value,
      category: form.querySelector("#post-category")?.value,
      subtitle: form.querySelector("#post-subtitle")?.value,
      body: form.querySelector("#post-body")?.value,
      author: form.querySelector("#post-author")?.value,
      rating: parseFloat(form.querySelector("#post-rating")?.value) || 5.0,
    };

    try {
      const res = await fetch(`${API_BASE_URL}/api/posts`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-key": ADMIN_KEY,
        },
        body: JSON.stringify(payload),
      });
      const data = await res.json();

      if (!res.ok) throw new Error(data.error || "Failed to publish");

      alert("Post published successfully!");
      form.reset();
      loadPosts(); // refresh list
    } catch (err) {
      alert("Error: " + err.message);
    }
  });
}

// ---------- 3. Handle newsletter "Subscribe Free" form ----------
function setupNewsletterForms() {
  document.querySelectorAll(".newsletter-form").forEach((form) => {
    // <-- give your newsletter <form> this class, or update selector
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const emailInput = form.querySelector('input[type="email"]');
      const email = emailInput?.value;

      try {
        const res = await fetch(`${API_BASE_URL}/api/subscribe`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Subscription failed");
        alert(data.message);
        form.reset();
      } catch (err) {
        alert("Error: " + err.message);
      }
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  loadPosts();
  setupPublishForm();
  setupNewsletterForms();
});
