# AIToolsPro Backend

Backend API for the AIToolsPro GitHub Pages site (`Ai-tools-blogs`). GitHub Pages
only serves static files, so this Node.js + Express + MongoDB backend handles:

- Saving and listing blog posts published via the "Write New Blog Post" form
- Newsletter email subscriptions
- Simple admin-key protection for publish/delete actions

## 1. Local setup

```bash
cd aitoolspro-backend
npm install
cp .env.example .env
```

Edit `.env`:
- `MONGODB_URI` — create a free cluster at https://www.mongodb.com/cloud/atlas
  (M0 free tier is enough). In Atlas: Database Access → create a user;
  Network Access → allow `0.0.0.0/0` (or Railway's IP); copy the connection string.
- `ADMIN_KEY` — any strong password you choose, e.g. `aitoolspro_9x7K2m`
- `ALLOWED_ORIGIN` — your GitHub Pages URL: `https://abdul7862626a-bit.github.io`

Run locally:
```bash
npm run dev
```
Server starts at `http://localhost:5000`.

## 2. Deploy to Railway (free tier, same as your WeTarseel project)

1. Push this folder to a new GitHub repo (e.g. `aitoolspro-backend`).
2. Go to https://railway.app → New Project → Deploy from GitHub repo.
3. Select the repo. Railway auto-detects Node.js.
4. In Railway → Variables tab, add the same 4 variables from `.env`
   (`PORT` not required, Railway sets it automatically — you can omit it).
5. Deploy. Railway gives you a public URL like:
   `https://aitoolspro-backend.up.railway.app`

## 3. Connect the frontend (GitHub Pages)

1. Open `frontend-integration.js` in this folder.
2. Replace `API_BASE_URL` with your Railway URL from step 2 above.
3. Replace `ADMIN_KEY` with the same value you set in Railway.
4. Add this script tag near the end of your `index.html`, just before `</body>`:
   ```html
   <script src="frontend-integration.js"></script>
   ```
5. **Important:** the `document.querySelector` calls in `frontend-integration.js`
   use placeholder IDs (`#post-title`, `#publish-post-form`, etc.). Share your
   actual `index.html` (or the repo link) and I'll match these selectors
   exactly to your real form/grid markup so it works without edits.

## API Endpoints

| Method | Endpoint            | Auth        | Purpose                          |
|--------|---------------------|-------------|-----------------------------------|
| GET    | `/api/posts`         | Public      | List all posts                   |
| GET    | `/api/posts/:slug`   | Public      | Get one post (+ increments views)|
| POST   | `/api/posts`         | Admin key   | Publish new post                 |
| DELETE | `/api/posts/:slug`   | Admin key   | Delete a post                    |
| POST   | `/api/subscribe`     | Public      | Subscribe email to newsletter    |
| GET    | `/api/subscribe`     | Admin key   | List all subscribers             |

Admin-key endpoints require this header:
```
x-admin-key: your-secret-from-.env
```

## Notes

- Free MongoDB Atlas tier (512MB) is more than enough for a blog like this.
- Railway free tier sleeps after inactivity on some plans — fine for a
  personal/client blog with moderate traffic; upgrade later if traffic grows.
- For real production use, also add rate-limiting on `/api/subscribe` and
  `/api/posts` to stop spam — happy to add that if you want.
