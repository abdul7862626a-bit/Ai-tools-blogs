const mongoose = require("mongoose");

const postSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    slug: { type: String, required: true, unique: true },
    category: { type: String, required: true },
    subtitle: { type: String, default: "" },
    body: { type: String, required: true },
    author: { type: String, required: true },
    rating: { type: Number, default: 5.0 },
    views: { type: Number, default: 0 },
    readTime: { type: String, default: "" },
  },
  { timestamps: true }
);

function makeSlug(title) {
  return title
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

module.exports = { Post: mongoose.model("Post", postSchema), makeSlug };
