// Very simple shared-secret auth for the "Write New Blog Post" form.
// The frontend sends this key in a header when publishing/deleting a post.
function requireAdmin(req, res, next) {
  const key = req.headers["x-admin-key"];
  if (!key || key !== process.env.ADMIN_KEY) {
    return res.status(401).json({ error: "Unauthorized. Invalid or missing admin key." });
  }
  next();
}

module.exports = requireAdmin;
